OPEN = "open"
CLOSED = "closed"